/**
 * Guava adapters.
 */
package org.jgrapht.graph.guava;
