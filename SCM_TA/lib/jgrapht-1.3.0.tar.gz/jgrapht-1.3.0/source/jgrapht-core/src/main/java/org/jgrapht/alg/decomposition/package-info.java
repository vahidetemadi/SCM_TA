/**
 * Algorithms for computing decompositions.
 */
package org.jgrapht.alg.decomposition;
